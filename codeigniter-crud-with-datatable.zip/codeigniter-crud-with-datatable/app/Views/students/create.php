<?= $this->extend('layouts/frontend.php') ?>

<?= $this->section('content') ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Student Data
                        <a href="<?= base_url('students') ?>" class="btn btn-danger btn-sm float-end">Back</a>
                    </h5>
                </div>
                <div class="card-body">
                    <form action="<?= base_url('students/add') ?>" method="POST">
                        
                        <!-- Display validation errors -->
                        <?php $validation = session()->get('validation'); ?>

                        <div class="form-group mb-2">
                            <label for="">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter Name" value="<?= old('name') ?>">
                            <?php if($validation && $validation->hasError('name')): ?>
                                <small class="text-danger"><?= $validation->getError('name'); ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-2">
                            <label for="">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter Email" value="<?= old('email') ?>">
                            <?php if($validation && $validation->hasError('email')): ?>
                                <small class="text-danger"><?= $validation->getError('email'); ?></small>
                            <?php endif; ?>
                        </div>
                        

                        
                        <div class="form-group mb-2">
                            <label for="">Phone</label>
                            <input type="text" name="phone" class="form-control" placeholder="Enter Phone" value="<?= old('phone') ?>">
                            <?php if($validation && $validation->hasError('phone')): ?>
                                <small class="text-danger"><?= $validation->getError('phone'); ?></small>
                            <?php endif; ?>
                        </div>
                        

                        <div class="form-group mb-2">
                            <label for="">Course</label>
                            <select name="course" class="form-control">
                                <option value="" disabled selected>Select Course</option>
                                <option value="Python" <?= old('course') == 'Python' ? 'selected' : '' ?>>Python</option>
                                <option value="JavaScript" <?= old('course') == 'JavaScript' ? 'selected' : '' ?>>JavaScript</option>
                                <option value="React" <?= old('course') == 'React' ? 'selected' : '' ?>>React</option>
                                <option value="CodeIgniter" <?= old('course') == 'CodeIgniter' ? 'selected' : '' ?>>CodeIgniter</option>
                                <option value="Laravel" <?= old('course') == 'Laravel' ? 'selected' : '' ?>>Laravel</option>
                            </select>
                            <?php if($validation && $validation->hasError('course')): ?>
                                <small class="text-danger"><?= $validation->getError('course'); ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-2">
                            <label for="">Gender</label><br>
                            <input type="radio" name="gender" value="Male" <?= old('gender') == 'Male' ? 'checked' : '' ?>> Male
                            <input type="radio" name="gender" value="Female" <?= old('gender') == 'Female' ? 'checked' : '' ?>> Female
                            <br>
                            <?php if($validation && $validation->hasError('gender')): ?>
                                <small class="text-danger"><?= $validation->getError('gender'); ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-2">
                            <input type="checkbox" name="terms" value="yes" <?= old('terms') == 'yes' ? 'checked' : '' ?>> I accept the terms and conditions
                           <br>
                            <?php if($validation && $validation->hasError('terms')): ?>
                                <small class="text-danger"><?= $validation->getError('terms'); ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary mt-5">Save</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
