
<?= $this->extend('layouts/frontend.php') ?>

<?= $this->section('content') ?>




<?= $this->endSection() ?>